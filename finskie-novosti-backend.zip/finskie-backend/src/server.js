// src/server.js
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const cron = require('node-cron');
const { fetchAllNews, getCachedNews } = require('./fetchNews');

const PORT = process.env.PORT || 3000;
const REFRESH_MIN = parseInt(process.env.REFRESH_INTERVAL_MINUTES || '15', 10);
const CORS_ORIGIN = process.env.CORS_ORIGIN || '*';

const app = express();
app.use(cors({ origin: CORS_ORIGIN === '*' ? '*' : CORS_ORIGIN.split(',') }));

let isRefreshing = false;
async function safeRefresh() {
  if (isRefreshing) return;
  isRefreshing = true;
  try {
    await fetchAllNews();
  } catch (err) {
    console.error('[safeRefresh] ошибка обновления:', err);
  } finally {
    isRefreshing = false;
  }
}

// GET /api/news — вся лента, опционально ?category=Политика&source=yle&limit=50
app.get('/api/news', (req, res) => {
  const { category, source, limit } = req.query;
  const data = getCachedNews();
  let items = data.items || [];

  if (category && category !== 'all') items = items.filter((i) => i.category === category);
  if (source) items = items.filter((i) => i.source === source);
  if (limit) items = items.slice(0, parseInt(limit, 10));

  res.json({ updatedAt: data.updatedAt, count: items.length, items });
});

// GET /api/news/sources — список источников и сколько новостей от каждого сейчас в кэше
app.get('/api/news/sources', (req, res) => {
  const data = getCachedNews();
  const counts = {};
  for (const item of data.items || []) {
    counts[item.source] = (counts[item.source] || 0) + 1;
  }
  res.json(counts);
});

// POST /api/news/refresh — форсировать обновление вручную (например, из админки)
app.post('/api/news/refresh', async (req, res) => {
  if (isRefreshing) return res.status(202).json({ status: 'already_running' });
  safeRefresh(); // не ждём — отвечаем сразу, обновление идёт в фоне
  res.json({ status: 'started' });
});

app.get('/api/health', (req, res) => res.json({ ok: true, time: new Date().toISOString() }));

app.listen(PORT, () => {
  console.log(`Финские Новости — API запущен на http://localhost:${PORT}`);
  console.log(`Обновление RSS каждые ${REFRESH_MIN} мин.`);
  // Первое обновление сразу при старте, чтобы не ждать 15 минут до первых данных
  safeRefresh();
});

// Периодическое обновление по cron (например, "*/15 * * * *")
cron.schedule(`*/${REFRESH_MIN} * * * *`, safeRefresh);
