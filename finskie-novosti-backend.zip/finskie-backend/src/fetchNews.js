// src/fetchNews.js
const fs = require('fs');
const path = require('path');
const Parser = require('rss-parser');
const { SOURCES, categorize } = require('./config');
const { getRussianVersion } = require('./russianVersion');
const { PROMPT_VERSION } = require('./aiRetell');

const parser = new Parser({
  timeout: 15000,
  headers: { 'User-Agent': 'FinskieNovostiBot/1.0 (+https://finskienovosti.fi)' },
});

const CACHE_PATH = path.join(__dirname, '..', 'data', 'translationCache.json');
const NEWS_CACHE_PATH = path.join(__dirname, '..', 'data', 'latestNews.json');

function loadJson(filePath, fallback) {
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf-8'));
  } catch {
    return fallback;
  }
}
function saveJson(filePath, data) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf-8');
}

// Кэш переводов: { [guidOrLink]: { titleFi, summaryFi, titleRu, summaryRu, method, translatedAt } }
// Экономит запросы к API перевода — уже переведённые новости не переводим повторно.
// Храним исходный titleFi/summaryFi вместе с переводом: если у источника
// поменялось содержимое под тем же guid/link (например, "живой" футбольный
// репортаж IS, который обновляется на одном и том же URL), кэш считается
// устаревшим и статья переводится заново.
let translationCache = loadJson(CACHE_PATH, {});

// Не больше N одновременных запросов к Anthropic API — иначе на большом
// количестве статей (у вас их 233 за раз) быстро упираемся в лимит запросов
// в минуту, и часть новостей остаётся непереведённой ("fallback-original").
function createLimiter(concurrency) {
  let active = 0;
  const queue = [];
  const runNext = () => {
    if (active >= concurrency || queue.length === 0) return;
    active++;
    const { fn, resolve, reject } = queue.shift();
    fn().then(resolve, reject).finally(() => { active--; runNext(); });
  };
  return (fn) => new Promise((resolve, reject) => { queue.push({ fn, resolve, reject }); runNext(); });
}
const limitAiCalls = createLimiter(parseInt(process.env.AI_CONCURRENCY || '3', 10));

function stripHtml(html = '') {
  return html
    .replace(/<[^>]*>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\s+/g, ' ')
    .trim();
}

function estimateReadMinutes(text = '') {
  const words = text.split(/\s+/).filter(Boolean).length;
  return Math.max(1, Math.round(words / 180)); // ~180 слов в минуту
}

async function fetchSource(source) {
  const items = [];
  try {
    const feed = await parser.parseURL(source.url);
    for (const entry of feed.items || []) {
      const titleFi = (entry.title || '').trim();
      const summaryFi = stripHtml(entry.contentSnippet || entry.content || entry.summary || '');
      if (!titleFi) continue;

      const key = entry.guid || entry.link || titleFi;
      const cached = translationCache[key];
      const cacheIsFresh = cached
        && cached.titleFi === titleFi
        && cached.summaryFi === summaryFi
        && cached.promptVersion === PROMPT_VERSION;

      let titleRu, summaryRu, method;
      if (cacheIsFresh) {
        titleRu = cached.titleRu;
        summaryRu = cached.summaryRu;
        method = cached.method;
      } else {
        const result = await limitAiCalls(() => getRussianVersion({
          titleFi,
          summaryFi: summaryFi.slice(0, 800), // ограничиваем длину — экономия на входных токенах/символах
          sourceName: source.name,
        }));
        titleRu = result.titleRu;
        summaryRu = result.summaryRu;
        method = result.method;
        // Не кэшируем неудачные попытки — иначе статья, которой не повезло
        // с API один раз, так и останется непереведённой навсегда.
        // При следующем обновлении (раз в 15 мин) попробуем ещё раз.
        if (method !== 'fallback-original') {
          translationCache[key] = {
            titleFi, summaryFi, titleRu, summaryRu, method,
            promptVersion: result.promptVersion ?? PROMPT_VERSION,
            translatedAt: new Date().toISOString(),
          };
        }
      }

      items.push({
        id: key,
        source: source.id,
        sourceName: source.name,
        category: categorize(titleFi, summaryFi),
        titleFi,
        titleRu,
        summaryFi,
        summaryRu,
        translationMethod: method, // 'ai-retelling' | 'deepl-literal' | ... — полезно для отладки и для UI-пометки "пересказ"
        link: entry.link,
        pubDate: entry.isoDate || entry.pubDate || null,
        readMinutes: estimateReadMinutes(summaryFi),
      });
    }
  } catch (err) {
    console.error(`[fetchSource] ${source.name} (${source.url}) — ошибка:`, err.message);
    // Специально не бросаем исключение дальше: один упавший источник
    // не должен ронять всю ленту.
  }
  return items;
}

async function fetchAllNews() {
  console.log('[fetchAllNews] старт обновления —', new Date().toISOString());
  const results = await Promise.all(SOURCES.map(fetchSource));
  let all = results.flat();

  // Сортировка по дате публикации, самые новые сверху
  all.sort((a, b) => new Date(b.pubDate || 0) - new Date(a.pubDate || 0));

  saveJson(CACHE_PATH, translationCache);
  saveJson(NEWS_CACHE_PATH, { updatedAt: new Date().toISOString(), items: all });

  console.log(`[fetchAllNews] готово: ${all.length} новостей из ${SOURCES.length} источников`);
  return all;
}

function getCachedNews() {
  const data = loadJson(NEWS_CACHE_PATH, { updatedAt: null, items: [] });
  return data;
}

// Поддержка запуска напрямую: node src/fetchNews.js --once
if (require.main === module) {
  require('dotenv').config();
  fetchAllNews()
    .then(() => process.exit(0))
    .catch((err) => {
      console.error(err);
      process.exit(1);
    });
}

module.exports = { fetchAllNews, getCachedNews };
